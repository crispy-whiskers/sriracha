module.exports.append = require('./functions/appendrow');
module.exports.get = require('./functions/getsheet');
module.exports.delete = require('./functions/removerow')
module.exports.overwrite = require('./functions/editrow');
